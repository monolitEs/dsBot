"""
The MIT License (MIT)

Copyright (c) 2015-2021 Rapptz
Copyright (c) 2021-present Pycord Development

Permission is hereby granted, free of charge, to any person obtaining a
copy of this software and associated documentation files (the "Software"),
to deal in the Software without restriction, including without limitation
the rights to use, copy, modify, merge, publish, distribute, sublicense,
and/or sell copies of the Software, and to permit persons to whom the
Software is furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS
OR IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING
FROM, OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER
DEALINGS IN THE SOFTWARE.
"""

from __future__ import annotations

import logging
import threading
import time
from collections.abc import Callable, Coroutine
from operator import itemgetter
from typing import TYPE_CHECKING, Any, Generic, Literal, Protocol, overload

import davey
import nacl.secret
from nacl.exceptions import CryptoError
from typing_extensions import TypeVarTuple, Unpack

from ..packets.rtp import ReceiverReportPacket, RTCPPacket, decode
from .router import PacketRouter, SinkEventRouter

if TYPE_CHECKING:
    from discord.member import Member
    from discord.sinks import Sink
    from discord.types.voice import SupportedModes

    from ..client import VoiceClient
    from ..packets import RTPPacket

    DecryptRTP = Callable[[RTPPacket], bytes]
    DecryptRTCP = Callable[[bytes], bytes]
    SpeakingEvent = Literal["member_speaking_start", "member_speaking_stop"]
    EncryptionBox = nacl.secret.SecretBox | nacl.secret.Aead

Ts = TypeVarTuple("Ts")


class AfterCallback(Protocol, Generic[Unpack[Ts]]):
    def __call__(
        self,
        sink: Sink,
        *args: Unpack[Ts],
    ) -> Coroutine[Any, Any, Any] | Any: ...


_log = logging.getLogger(__name__)

__all__ = ("AudioReader",)


def is_rtcp(data: bytes) -> bool:
    return 200 <= data[1] <= 204


class AudioReader(Generic[Unpack[Ts]]):
    @overload
    def __init__(
        self,
        sink: Sink,
        client: VoiceClient,
        *,
        after: None = None,
        args: None = None,
        start: bool = False,
    ) -> None: ...

    @overload
    def __init__(
        self,
        sink: Sink,
        client: VoiceClient,
        *,
        after: AfterCallback[Unpack[Ts]],
        args: tuple[Unpack[Ts]],
        start: bool = False,
    ) -> None: ...

    def __init__(
        self,
        sink: Sink,
        client: VoiceClient,
        *,
        after: AfterCallback[Unpack[Ts]] | None = None,
        args: tuple[Unpack[Ts]] | None = None,
        start: bool = False,
    ) -> None:
        if after is not None and not callable(
            after
        ):  # pyright: ignore[reportUnnecessaryComparison]
            raise TypeError(  # pyright: ignore[reportUnreachable]
                f"expected a callable for the 'after' parameter, got {after.__class__.__name__!r} instead"
            )

        self.sink: Sink = sink
        self.client: VoiceClient = client
        self.after: AfterCallback[Unpack[Ts]] | None = after
        self.args: tuple[Unpack[Ts]] | None = args

        self.sink.init(client)

        self.active: bool = False
        self.error: Exception | None = None
        self.packet_router: PacketRouter = PacketRouter(self.sink, self)
        self.event_router: SinkEventRouter = SinkEventRouter(self.sink, self)
        self.decryptor: PacketDecryptor = PacketDecryptor(
            client.mode, bytes(client.secret_key), client
        )
        self.speaking_timer: SpeakingTimer[Unpack[Ts]] = SpeakingTimer(self)
        self.keep_alive: UDPKeepAlive = UDPKeepAlive(client)

        if start:
            self.start()

    def is_listening(self) -> bool:
        return self.active

    def update_secret_key(self, secret_key: bytes) -> None:
        self.decryptor.update_secret_key(secret_key)

    def start(self) -> None:
        if self.active:
            _log.debug("Reader is already running", exc_info=True)
            return

        self.client._connection.add_socket_listener(self.callback)
        self.speaking_timer.start()
        self.event_router.start()
        self.packet_router.start()
        self.keep_alive.start()
        self.active = True

    def stop(self) -> None:
        if not self.active:
            _log.debug("Reader is not active")
            return

        self.active = False
        self.client._connection.remove_socket_listener(self.callback)
        self.speaking_timer.notify()
        self._stop()

    def _stop(self) -> None:
        try:
            if self.packet_router.is_alive():
                self.packet_router.stop()
                if threading.current_thread() is not self.packet_router:
                    self.packet_router.join(timeout=5)
        except Exception as exc:
            self.error = exc
            _log.exception("An error occurred while stopping packet router.")

        try:
            self.event_router.stop()
        except Exception as exc:
            self.error = exc
            _log.exception("An error occurred while stopping event router.")

        self.speaking_timer.stop()
        self.keep_alive.stop()

        if self.after and self.args:
            try:
                r = self.after(self.sink, *self.args)
                if isinstance(r, Coroutine):
                    self.client.loop.create_task(
                        r
                    )  # pyright: ignore[reportUnknownArgumentType]
            except Exception:
                _log.exception(
                    "An error occurred while calling the after callback on audio reader"
                )

        try:
            self.sink.cleanup()
        except Exception as exc:
            _log.exception("Error calling cleanup() for %s", self.sink, exc_info=exc)

    def set_sink(self, sink: Sink) -> Sink:
        old_sink = self.sink
        self.packet_router.set_sink(sink)
        self.sink = sink
        return old_sink

    def _is_ip_discovery_packet(self, data: bytes) -> bool:
        return len(data) == 74 and data[1] == 0x02

    def callback(self, packet_data: bytes) -> None:
        packet = rtp_packet = rtcp_packet = None
        pending_exc: BaseException | None = None

        try:
            if not is_rtcp(packet_data):
                packet = rtp_packet = decode(packet_data)
                packet.decrypted_data = self.decryptor.decrypt_rtp(packet)  # type: ignore
            else:
                packet = rtcp_packet = decode(packet_data)
                if not isinstance(packet, ReceiverReportPacket):
                    _log.info(
                        "Received unexpected rtcp packet type=%s, %s",
                        packet.type,
                        type(packet),
                    )
        except CryptoError as exc:
            _log.error("CryptoError while decoding a voice packet", exc_info=exc)
            return
        except Exception as exc:
            if self._is_ip_discovery_packet(packet_data):
                _log.debug("Received an IP Discovery Packet, ignoring...")
                return
            _log.exception(
                "An exception occurred while decoding voice packets", exc_info=exc
            )
        except BaseException as exc:
            pending_exc = exc

        if self.error:
            _log.debug("Callback errored out, stopping: %s", self.error)
            self.stop()
            return

        if not packet:
            _log.debug("No packet found after callback")
            return

        if pending_exc is not None:
            raise pending_exc

        if rtcp_packet:
            self.packet_router.feed_rtcp(rtcp_packet)  # type: ignore
        elif rtp_packet:
            if not rtp_packet.decrypted_data:
                _log.debug(
                    "No decrypted data for RTP packet, this should be safe to ignore."
                )
                return

            ssrc = rtp_packet.ssrc

            if ssrc not in self.client._connection.ssrc_user_map:
                if rtp_packet.is_silence():
                    return
                else:
                    _log.info(
                        "Received a packet for unknown SSRC %s: %s", ssrc, rtp_packet
                    )
                    _log.debug(
                        "Current SSRCs: %s", self.client._connection.ssrc_user_map
                    )

            self.speaking_timer.notify(ssrc)

            try:
                _log.debug("Feeding packet to packet router")
                self.packet_router.feed_rtp(rtp_packet)  # type: ignore
            except Exception as exc:
                _log.exception(
                    "An error occurred while processing RTP packet %s", rtp_packet
                )
                self.error = exc
                self.stop()


class PacketDecryptor:
    supported_modes: list[SupportedModes] = [
        "aead_xchacha20_poly1305_rtpsize",
        "xsalsa20_poly1305",
        "xsalsa20_poly1305_lite",
        "xsalsa20_poly1305_suffix",
    ]

    def __init__(
        self, mode: SupportedModes, secret_key: bytes, client: VoiceClient
    ) -> None:
        self.mode: SupportedModes = mode
        self.client: VoiceClient = client

        try:
            self._decryptor_rtp: DecryptRTP = getattr(self, "_decrypt_rtp_" + mode)
            self._decryptor_rtcp: DecryptRTCP = getattr(self, "_decrypt_rtcp_" + mode)
        except AttributeError as exc:
            raise NotImplementedError(mode) from exc

        self.box: EncryptionBox = self._make_box(secret_key)

    def _make_box(self, secret_key: bytes) -> EncryptionBox:
        if self.mode.startswith("aead"):
            return nacl.secret.Aead(secret_key)
        else:
            return nacl.secret.SecretBox(secret_key)

    def decrypt_rtp(self, packet: RTPPacket) -> bytes:
        state = self.client._connection
        dave = state.dave_session

        raw_payload = self._decryptor_rtp(packet)

        if dave is not None and dave.ready:
            uid = state.ssrc_user_map.get(packet.ssrc)

            if uid:
                try:
                    raw_payload = dave.decrypt(
                        uid,
                        davey.MediaType.audio,
                        raw_payload,
                    )
                except ValueError:
                    # UnencryptedWhenPassthroughDisabled — drop the packet so the opus
                    # decoder uses PLC/FEC instead of decoding an explicit silence frame.
                    _log.debug(
                        "DAVE: Decryption failed, dropping packet for PLC",
                        exc_info=True,
                    )
                    raw_payload = b""
            else:
                # SSRC -> user_id mapping not yet populated (race with member_connect).
                raw_payload = b""

            packet.decrypted_data = raw_payload
        else:  # e.g., stage channels
            packet.decrypted_data = raw_payload

        return packet.decrypted_data or b""

    def decrypt_rtcp(self, packet: bytes) -> bytes:
        data = self._decryptor_rtcp(packet)

        if len(data) < 8:
            return data

        p_header = RTCPPacket.from_data(data)
        ssrc = p_header.ssrc

        state = self.client._connection
        dave = state.dave_session

        if dave is not None and dave.ready and ssrc in state.ssrc_user_map:
            try:
                return dave.decrypt(
                    state.ssrc_user_map[ssrc],
                    davey.MediaType.audio,
                    data,
                )
            except ValueError:
                _log.debug("DAVE: RTCP decryption failed", exc_info=True)

        return data

    def update_secret_key(self, secret_key: bytes) -> None:
        self.box = self._make_box(secret_key)

    def _decrypt_rtp_xsalsa20_poly1305(self, packet: RTPPacket) -> bytes:
        nonce = bytearray(24)
        nonce[:12] = packet.header
        result = self.box.decrypt(bytes(packet.data), bytes(nonce))

        if packet.extended:
            offset = packet.update_extended_header(result)
            result = result[offset:]

        return packet.strip_padding(result)

    def _decrypt_rtcp_xsalsa20_poly1305(self, data: bytes) -> bytes:
        nonce = bytearray(24)
        nonce[:8] = data[:8]
        result = self.box.decrypt(data[8:], bytes(nonce))

        return data[:8] + result

    def _decrypt_rtp_xsalsa20_poly1305_suffix(self, packet: RTPPacket) -> bytes:
        nonce = packet.data[-24:]
        voice_data = packet.data[:-24]
        result = self.box.decrypt(bytes(voice_data), bytes(nonce))

        if packet.extended:
            offset = packet.update_extended_header(result)
            result = result[offset:]

        return packet.strip_padding(result)

    def _decrypt_rtcp_xsalsa20_poly1305_suffix(self, data: bytes) -> bytes:
        nonce = data[-24:]
        header = data[:8]
        result = self.box.decrypt(data[8:-24], nonce)

        return header + result

    def _decrypt_rtp_xsalsa20_poly1305_lite(self, packet: RTPPacket) -> bytes:
        nonce = bytearray(24)
        nonce[:4] = packet.data[-4:]
        voice_data = packet.data[:-4]
        result = self.box.decrypt(bytes(voice_data), bytes(nonce))

        if packet.extended:
            offset = packet.update_extended_header(result)
            result = result[offset:]

        return packet.strip_padding(result)

    def _decrypt_rtcp_xsalsa20_poly1305_lite(self, data: bytes) -> bytes:
        nonce = bytearray(24)
        nonce[:4] = data[-4:]
        header = data[:8]
        result = self.box.decrypt(data[8:-4], bytes(nonce))

        return header + result

    def _decrypt_rtp_aead_xchacha20_poly1305_rtpsize(self, packet: RTPPacket) -> bytes:
        _log.debug(
            "Decrypting RTP AEAD XChaCha20 Poly1305 RTPSize, has decrypted data?: %s",
            packet.decrypted_data is not None,
        )
        packet.adjust_rtpsize()
        nonce = packet.nonce + b"\x00" * 20

        assert isinstance(self.box, nacl.secret.Aead)

        try:
            result = self.box.decrypt(
                packet.decrypted_data or packet.data,
                bytes(packet.header),
                nonce,
            )
        except Exception as exc:
            _log.error("Critical error at AEAD: %s", exc)
            raise CryptoError(exc)

        if packet.extended:
            offset = packet.update_extended_header(result)
            result = result[offset:]

        return packet.strip_padding(result)

    def _decrypt_rtcp_aead_xchacha20_poly1305_rtpsize(self, data: bytes) -> bytes:
        _log.debug("Decrypting RTCP AEAD XChaCha20 Poly1305 RTPSize")
        nonce = bytearray(24)
        nonce[:4] = data[-4:]
        header = data[:8]

        assert isinstance(self.box, nacl.secret.Aead)
        result = self.box.decrypt(data[8:-4], bytes(header), bytes(nonce))

        return header + result


class SpeakingTimer(threading.Thread, Generic[Unpack[Ts]]):
    def __init__(self, reader: AudioReader[Unpack[Ts]]) -> None:
        super().__init__(
            daemon=True,
            name=f"voice-receiver-speaking-timer:{id(self):#x}",
        )

        self.reader: AudioReader[Unpack[Ts]] = reader
        self.client: VoiceClient = reader.client
        self.speaking_timeout_delay: float = 0.2
        self.last_speaking_state: dict[int, bool] = {}
        self.speaking_cache: dict[int, float] = {}
        self.speaking_timer: threading.Condition = threading.Condition()
        self._end_thread: threading.Event = threading.Event()

    def _lookup_member(self, ssrc: int) -> Member | None:
        id = self.client._connection.ssrc_user_map.get(ssrc)
        if not self.client.guild:
            return None
        return self.client.guild.get_member(id) if id else None

    def maybe_dispatch_speaking_start(self, ssrc: int) -> None:
        tlast = self.speaking_cache.get(ssrc)
        if tlast is None or tlast + self.speaking_timeout_delay < time.perf_counter():
            self.dispatch("member_speaking_start", ssrc)

    def dispatch(self, event: SpeakingEvent, ssrc: int) -> None:
        member = self._lookup_member(ssrc)
        if not member:
            return None
        self.client._dispatch_sink(event, member)

    def notify(self, ssrc: int | None = None) -> None:
        with self.speaking_timer:
            if ssrc is not None:
                self.last_speaking_state[ssrc] = True
                self.maybe_dispatch_speaking_start(ssrc)
                self.speaking_cache[ssrc] = time.perf_counter()

            self.speaking_timer.notify()

    def drop_ssrc(self, ssrc: int) -> None:
        with self.speaking_timer:
            self.speaking_cache.pop(ssrc, None)
            state = self.last_speaking_state.pop(ssrc, None)

        if state:
            self.dispatch("member_speaking_stop", ssrc)
        self.notify()

    def get_speaking(self, ssrc: int) -> bool | None:
        return self.last_speaking_state.get(ssrc)

    def stop(self) -> None:
        self._end_thread.set()
        self.notify()

    def run(self) -> None:
        _i1 = itemgetter(1)

        def get_next_entry():
            cache = sorted(self.speaking_cache.items(), key=_i1)
            for ssrc, tlast in cache:
                if self.last_speaking_state.get(ssrc):
                    return ssrc, tlast
            return None, None

        while not self._end_thread.is_set():
            stopped_ssrc = None

            with self.speaking_timer:
                if not self.speaking_cache:
                    self.speaking_timer.wait()
                    continue

                tnow = time.perf_counter()
                ssrc, tlast = get_next_entry()

                if ssrc is None or tlast is None:
                    self.speaking_timer.wait()
                    continue

                delay = tlast + self.speaking_timeout_delay - tnow
                if delay > 0:
                    self.speaking_timer.wait(delay)
                    continue

                self.last_speaking_state[ssrc] = False
                stopped_ssrc = ssrc

            if stopped_ssrc is not None:
                self.dispatch("member_speaking_stop", stopped_ssrc)


class UDPKeepAlive(threading.Thread):
    delay: int = 5000

    def __init__(self, client: VoiceClient) -> None:
        super().__init__(
            daemon=True,
            name=f"voice-receiver-udp-keep-alive:{id(self):#x}",
        )

        self.client: VoiceClient = client
        self.last_time: float = 0
        self.counter: int = 0
        self._end_thread: threading.Event = threading.Event()

    def run(self) -> None:
        self.client.wait_until_connected()

        while not self._end_thread.is_set():
            vc = self.client

            try:
                packet = self.counter.to_bytes(8, "big")
            except OverflowError:
                self.counter = 0
                continue

            try:
                vc._connection.socket.sendto(
                    packet, (vc._connection.endpoint_ip, vc._connection.voice_port)
                )
            except Exception as exc:
                _log.debug(
                    "Error while sending udp keep alive to socket %s at %s:%s",
                    vc._connection.socket,
                    vc._connection.endpoint_ip,
                    vc._connection.voice_port,
                    exc_info=exc,
                )
                vc.wait_until_connected()
                if vc.is_connected():
                    continue
                break
            else:
                self.counter += 1
                time.sleep(self.delay)

    def stop(self) -> None:
        self._end_thread.set()
